package com.androidchatapp;

public class UserDetails {
    static String id = "";
    static String name    = "";
    static String password = "";
    static String chatWith = "";
    static  String no ="";
    static  String add="";
    static  String permission ="";
}
